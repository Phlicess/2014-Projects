/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     2014/8/28 ������ 15:21:36                       */
/*==============================================================*/


if exists (select 1
            from  sysobjects
           where  id = object_id('GuanLiYuan')
            and   type = 'U')
   drop table GuanLiYuan
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('QunZu')
            and   name  = 'GuanLiZhe_QunZu_FK'
            and   indid > 0
            and   indid < 255)
   drop index QunZu.GuanLiZhe_QunZu_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('QunZu')
            and   type = 'U')
   drop table QunZu
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('Relationship_8')
            and   name  = 'Relationship_11_FK'
            and   indid > 0
            and   indid < 255)
   drop index Relationship_8.Relationship_11_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('Relationship_8')
            and   name  = 'Relationship_10_FK'
            and   indid > 0
            and   indid < 255)
   drop index Relationship_8.Relationship_10_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Relationship_8')
            and   type = 'U')
   drop table Relationship_8
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('RenWu')
            and   name  = 'FaBuZhe_RenWu_FK'
            and   indid > 0
            and   indid < 255)
   drop index RenWu.FaBuZhe_RenWu_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('RenWu')
            and   type = 'U')
   drop table RenWu
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('WenJian')
            and   name  = 'Relationship_6_FK'
            and   indid > 0
            and   indid < 255)
   drop index WenJian.Relationship_6_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('WenJian')
            and   name  = 'RenWu_WenJian_FK'
            and   indid > 0
            and   indid < 255)
   drop index WenJian.RenWu_WenJian_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('WenJian')
            and   type = 'U')
   drop table WenJian
go

if exists (select 1
            from  sysobjects
           where  id = object_id('YongHu')
            and   type = 'U')
   drop table YongHu
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('YongHu_QunZu')
            and   name  = 'YongHu_QunZu2_FK'
            and   indid > 0
            and   indid < 255)
   drop index YongHu_QunZu.YongHu_QunZu2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('YongHu_QunZu')
            and   name  = 'YongHu_QunZu_FK'
            and   indid > 0
            and   indid < 255)
   drop index YongHu_QunZu.YongHu_QunZu_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('YongHu_QunZu')
            and   type = 'U')
   drop table YongHu_QunZu
go

/*==============================================================*/
/* Table: GuanLiYuan                                            */
/*==============================================================*/
create table GuanLiYuan (
   ID                   int                  not null,
   Name                 nvarchar(50)         null,
   Department           nvarchar(50)         null,
   Email                nvarchar(50)         null,
   Phone                nvarchar(20)         null,
   Password             nvarchar(20)         null,
   constraint PK_GUANLIYUAN primary key nonclustered (ID)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����Ա',
   'user', @CurrentUser, 'table', 'GuanLiYuan'
go

/*==============================================================*/
/* Table: QunZu                                                 */
/*==============================================================*/
create table QunZu (
   ID                   int                  not null,
   YongHu_ID            int                  null,
   GroupName            nvarchar(50)         null,
   GroupExplain         nvarchar(100)        null,
   MemberNum            int                  null,
   PublicGroup          bit                  null,
   constraint PK_QUNZU primary key nonclustered (ID)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'Ⱥ��',
   'user', @CurrentUser, 'table', 'QunZu'
go

/*==============================================================*/
/* Index: GuanLiZhe_QunZu_FK                                    */
/*==============================================================*/
create index GuanLiZhe_QunZu_FK on QunZu (
YongHu_ID ASC
)
go

/*==============================================================*/
/* Table: Relationship_8                                        */
/*==============================================================*/
create table Relationship_8 (
   YongHu_ID            int                  not null,
   RenWu_ID             int                  not null,
   ReadOrNo             bit                  null,
   FinishOrNo           bit                  null,
   constraint PK_RELATIONSHIP_8 primary key (YongHu_ID, RenWu_ID)
)
go

/*==============================================================*/
/* Index: Relationship_10_FK                                    */
/*==============================================================*/
create index Relationship_10_FK on Relationship_8 (
YongHu_ID ASC
)
go

/*==============================================================*/
/* Index: Relationship_11_FK                                    */
/*==============================================================*/
create index Relationship_11_FK on Relationship_8 (
RenWu_ID ASC
)
go

/*==============================================================*/
/* Table: RenWu                                                 */
/*==============================================================*/
create table RenWu (
   ID                   int                  not null,
   YongHu_ID            int                  null,
   TaskName             nvarchar(50)         null,
   FileName             nvarchar(50)         null,
   FileSize             nvarchar(20)         null,
   FileType             nvarchar(10)         null,
   UploadTime           datetime             null,
   CloseTime            datetime             null,
   Publiser             nvarchar(20)         null,
   Remark               nvarchar(500)        null,
   FilePath             nvarchar(100)        null,
   constraint PK_RENWU primary key nonclustered (ID)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����',
   'user', @CurrentUser, 'table', 'RenWu'
go

/*==============================================================*/
/* Index: FaBuZhe_RenWu_FK                                      */
/*==============================================================*/
create index FaBuZhe_RenWu_FK on RenWu (
YongHu_ID ASC
)
go

/*==============================================================*/
/* Table: WenJian                                               */
/*==============================================================*/
create table WenJian (
   ID                   int                  not null,
   YongHu_ID            int                  null,
   RenWu_ID             int                  null,
   FileName             nvarchar(50)         null,
   Size                 nvarchar(20)         null,
   Type                 nvarchar(10)         null,
   UploadTime           datetime             null,
   Uploader             nvarchar(20)         null,
   FilePath             nvarchar(100)        null,
   constraint PK_WENJIAN primary key nonclustered (ID)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�ļ�',
   'user', @CurrentUser, 'table', 'WenJian'
go

/*==============================================================*/
/* Index: RenWu_WenJian_FK                                      */
/*==============================================================*/
create index RenWu_WenJian_FK on WenJian (
RenWu_ID ASC
)
go

/*==============================================================*/
/* Index: Relationship_6_FK                                     */
/*==============================================================*/
create index Relationship_6_FK on WenJian (
YongHu_ID ASC
)
go

/*==============================================================*/
/* Table: YongHu                                                */
/*==============================================================*/
create table YongHu (
   ID                   int                  not null,
   Name                 nvarchar(10)         null,
   Phone                nvarchar(20)         null,
   Email                nvarchar(50)         null,
   Position             nvarchar(50)         null,
   State                bit                  null,
   Password             nvarchar(20)         null,
   constraint PK_YONGHU primary key nonclustered (ID)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�û�',
   'user', @CurrentUser, 'table', 'YongHu'
go

/*==============================================================*/
/* Table: YongHu_QunZu                                          */
/*==============================================================*/
create table YongHu_QunZu (
   YongHu_ID            int                  not null,
   QunZu_ID             int                  not null,
   constraint PK_YONGHU_QUNZU primary key (YongHu_ID, QunZu_ID)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�û� Ⱥ��',
   'user', @CurrentUser, 'table', 'YongHu_QunZu'
go

/*==============================================================*/
/* Index: YongHu_QunZu_FK                                       */
/*==============================================================*/
create index YongHu_QunZu_FK on YongHu_QunZu (
YongHu_ID ASC
)
go

/*==============================================================*/
/* Index: YongHu_QunZu2_FK                                      */
/*==============================================================*/
create index YongHu_QunZu2_FK on YongHu_QunZu (
QunZu_ID ASC
)
go

